import logo from './logo.svg';
import './App.css';
import index from './index.js'

function App() {
  return (
    
    <div>
      <index />
    </div>

  );
}

export default App;
